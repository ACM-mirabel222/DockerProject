# Tents in SA – Rental Analytics (synthetic project)

A demo data-analysis + machine-learning project for **Tents in SA**, a fictional client that rents
rooms, flats, cottages and houses to tenants across South Africa's provinces.

> All data is **synthetic** (randomly generated, fixed seed). No real people or properties.

## What it does

| Step | Script | Output (in `outputs/`) |
|------|--------|------------------------|
| 1. Dataset (100 rentals) | `src/generate_data.py` | `data/tents_in_sa_rentals.csv` |
| 2. Exploratory analysis | `src/analysis.py` | summary CSVs + 5 charts (PNG) |
| 3. Machine learning | `src/train_model.py` | `rent_model.joblib`, `renewal_model.joblib`, `metrics.json` |
| 4. Dashboard | `src/app.py` (Panel) | interactive site on port 5006 |

**ML tasks**
- **Regression** – predict a property's monthly rent (Ridge / Random Forest / Gradient Boosting compared).
- **Classification** – predict whether a tenant will renew their lease (Logistic Regression / Random Forest).

Models are compared with 5-fold cross-validation; the best of each is saved and used by the dashboard.

## Run it (only Docker required)

```bash
git clone <your-repo-url>
cd tents-in-sa
docker compose up --build
```

Wait for the line `Dashboard starting`, then open **http://localhost:5006/app**.
Stop with `Ctrl+C`, then `docker compose down`.

Without Compose:
```bash
docker build -t tents-in-sa .
docker run --rm -p 5006:5006 -v "$(pwd)/outputs:/app/outputs" tents-in-sa
```
(On Windows PowerShell replace `$(pwd)` with `${PWD}`.)

Analysis tables, charts, trained models and `metrics.json` appear in the `outputs/` folder on your computer.

## Dashboard tabs
1. **Explore data** – filter by province / property type; KPIs, charts, table.
2. **Rent predictor** – describe a property, get a suggested monthly rent.
3. **Renewal predictor** – describe a tenancy, get a renewal probability and advice.
4. **Model report** – cross-validation metrics and analysis charts.

## Dataset columns (`data/tents_in_sa_rentals.csv`)
`record_id, province, city, property_type, bedrooms, bathrooms, size_sqm, furnished, wifi, parking,
security, backup_power, distance_to_centre_km, tenant_type, tenant_age, tenant_monthly_income_zar,
lease_months, start_date, monthly_rent_zar, deposit_zar, tenant_rating, late_payment, renewed`

## Project layout
```
tents-in-sa/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── data/tents_in_sa_rentals.csv
├── outputs/                 # created on run
└── src/
    ├── config.py  generate_data.py  analysis.py  train_model.py  app.py  main.py
```

## Regenerate the data
Delete `data/tents_in_sa_rentals.csv` and run again (it is recreated automatically), or change
`N_RECORDS` / `SEED` in `src/config.py`.

## Caveats
- Only 100 records: model scores are for demonstration, not for real pricing decisions.
- The renewal model is only modestly better than guessing (~60% accuracy, AUC ≈ 0.6) – realistic for
  such a small, noisy sample, and a good talking point for "what data would we need to collect?".
- Provinces with few records (e.g. Limpopo) give unstable averages.

## Run without Docker (optional)
```bash
pip install -r requirements.txt
python src/main.py
```
