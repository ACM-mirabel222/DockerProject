"""Create the synthetic dataset: 100 rentals offered by 'Tents in SA'.

Every row is one tenancy (a room or house rented to a tenant) in a South
African province. All values are randomly generated (seed fixed, so the file
is reproducible) - no real people or properties.
"""
import numpy as np
import pandas as pd

from config import CITY_TO_PROVINCE, DATA_DIR, DATA_FILE, LOCATIONS, N_RECORDS, SEED

# rand price per m2 by property type (before city index / amenities)
RATE_PER_SQM = {"Room": 200, "Flat": 150, "Cottage": 130, "House": 105}
SIZE_RANGE = {"Room": (12, 26), "Flat": (30, 65), "Cottage": (40, 95), "House": (75, 210)}

# which property a tenant type tends to rent: [Room, Flat, Cottage, House]
PROPERTY_MIX = {
    "Student": [0.70, 0.25, 0.05, 0.00],
    "Young Professional": [0.20, 0.50, 0.20, 0.10],
    "Family": [0.00, 0.10, 0.15, 0.75],
    "Contract Worker": [0.45, 0.35, 0.10, 0.10],
}
TENANT_MIX = [0.25, 0.30, 0.25, 0.20]
# (median monthly income in ZAR, spread) per tenant type
INCOME = {
    "Student": (8000, 0.30),
    "Young Professional": (26000, 0.30),
    "Family": (42000, 0.35),
    "Contract Worker": (18000, 0.30),
}
MEAN_AGE = {"Student": 21, "Young Professional": 29, "Family": 38, "Contract Worker": 33}


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def generate(n: int = N_RECORDS, seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    cities = list(CITY_TO_PROVINCE)
    # weight the big metros more heavily
    city_w = np.array([3.0 if c in ("Johannesburg", "Cape Town", "Durban", "Pretoria") else 1.5 for c in cities])
    city_w = city_w / city_w.sum()

    rows = []
    for i in range(n):
        city = str(rng.choice(cities, p=city_w))
        province = CITY_TO_PROVINCE[city]
        idx = LOCATIONS[province][city]

        tenant = str(rng.choice(list(PROPERTY_MIX), p=TENANT_MIX))
        ptype = str(rng.choice(["Room", "Flat", "Cottage", "House"], p=PROPERTY_MIX[tenant]))

        lo, hi = SIZE_RANGE[ptype]
        size = float(round(rng.uniform(lo, hi)))
        if ptype == "Room":
            beds, baths = 1, 1
        elif ptype == "Flat":
            beds, baths = int(rng.choice([1, 2], p=[0.6, 0.4])), 1
        elif ptype == "Cottage":
            beds, baths = int(rng.choice([1, 2], p=[0.55, 0.45])), 1
        else:
            beds = int(np.clip(round(size / 45), 2, 5))
            baths = int(np.clip(beds - 1, 1, 3))

        furnished = int(rng.random() < (0.65 if ptype in ("Room", "Flat") else 0.30))
        wifi = int(rng.random() < 0.70)
        parking = int(rng.random() < (0.30 if ptype == "Room" else 0.75))
        security = int(rng.random() < (0.45 + 0.15 * (idx > 1.0)))
        backup_power = int(rng.random() < 0.40)           # solar / inverter (load-shedding)
        distance = round(float(rng.gamma(2.0, 4.0)), 1)   # km to city centre

        rent = (
            size * RATE_PER_SQM[ptype] * idx
            * (1 + 0.12 * furnished + 0.05 * wifi + 0.06 * parking + 0.07 * security + 0.05 * backup_power)
            * (1 - 0.006 * min(distance, 25))
            * rng.lognormal(0, 0.06)
        )
        rent = float(np.round(rent / 50) * 50)             # nearest R50

        med, spread = INCOME[tenant]
        income = float(rng.lognormal(np.log(med), spread))
        if rent / income > 0.70:                           # keep affordability realistic
            income = rent / rng.uniform(0.35, 0.65)
        income = float(np.round(income / 100) * 100)
        ratio = rent / income

        lease = int(rng.choice([6, 12, 24], p=[0.25, 0.55, 0.20]))
        age = int(np.clip(rng.normal(MEAN_AGE[tenant], 4), 18, 65))
        deposit = float(rent * rng.choice([1, 1.5, 2], p=[0.5, 0.3, 0.2]))

        rating = float(np.clip(np.round(
            3.7 + 0.25 * furnished + 0.15 * wifi + 0.2 * security + 0.15 * backup_power
            - 0.01 * distance + rng.normal(0, 0.5), 1), 1.0, 5.0))
        late = int(rng.random() < sigmoid(-2.4 + 5.5 * (ratio - 0.35)))
        renewed = int(rng.random() < sigmoid(-0.4 + 1.3 * (rating - 3.8) - 3.0 * (ratio - 0.4) - 1.2 * late))
        start = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 900)))

        rows.append(dict(
            record_id=f"TSA-{i + 1:03d}", province=province, city=city, property_type=ptype,
            bedrooms=beds, bathrooms=baths, size_sqm=size, furnished=furnished, wifi=wifi,
            parking=parking, security=security, backup_power=backup_power,
            distance_to_centre_km=distance, tenant_type=tenant, tenant_age=age,
            tenant_monthly_income_zar=income, lease_months=lease, start_date=start.date().isoformat(),
            monthly_rent_zar=rent, deposit_zar=deposit, tenant_rating=rating,
            late_payment=late, renewed=renewed,
        ))
    return pd.DataFrame(rows)


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df = generate()
    df.to_csv(DATA_FILE, index=False)
    print(f"[generate] wrote {len(df)} records -> {DATA_FILE}")


if __name__ == "__main__":
    main()
