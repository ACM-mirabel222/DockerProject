"""Train and compare ML models, save the best of each to outputs/.

1. Regression      -> predict monthly_rent_zar (pricing tool for the client)
2. Classification  -> predict whether a tenant renews (retention tool)
"""
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingRegressor, RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import KFold, StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import DATA_FILE, OUT_DIR, SEED

RENT_CAT = ["province", "city", "property_type"]
RENT_NUM = ["bedrooms", "bathrooms", "size_sqm", "furnished", "wifi", "parking",
            "security", "backup_power", "distance_to_centre_km"]

RENEW_CAT = ["province", "property_type", "tenant_type"]
RENEW_NUM = ["monthly_rent_zar", "tenant_monthly_income_zar", "rent_to_income", "tenant_rating",
             "late_payment", "lease_months", "tenant_age", "furnished", "security"]


def prep(scale: bool, cat, num):
    return ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat),
        ("num", StandardScaler() if scale else "passthrough", num),
    ])


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA_FILE)
    df["rent_to_income"] = df["monthly_rent_zar"] / df["tenant_monthly_income_zar"]
    metrics = {}

    # ---------- 1. rent regression
    X, y = df[RENT_CAT + RENT_NUM], df["monthly_rent_zar"]
    candidates = {
        "Ridge": Pipeline([("p", prep(True, RENT_CAT, RENT_NUM)), ("m", Ridge(alpha=1.0))]),
        "RandomForest": Pipeline([("p", prep(False, RENT_CAT, RENT_NUM)),
                                  ("m", RandomForestRegressor(300, random_state=SEED))]),
        "GradientBoosting": Pipeline([("p", prep(False, RENT_CAT, RENT_NUM)),
                                      ("m", GradientBoostingRegressor(random_state=SEED))]),
    }
    cv = KFold(5, shuffle=True, random_state=SEED)
    res = {}
    for name, pipe in candidates.items():
        s = cross_validate(pipe, X, y, cv=cv, scoring=("r2", "neg_mean_absolute_error"))
        res[name] = {"cv_r2": round(float(s["test_r2"].mean()), 3),
                     "cv_mae_zar": round(float(-s["test_neg_mean_absolute_error"].mean()), 0)}
        print(f"[train] rent  {name:<17} R2={res[name]['cv_r2']:.3f}  MAE=R{res[name]['cv_mae_zar']:,.0f}")
    best = min(res, key=lambda k: res[k]["cv_mae_zar"])
    model = candidates[best].fit(X, y)
    joblib.dump(model, OUT_DIR / "rent_model.joblib")
    metrics["rent_regression"] = {"best_model": best, "cv_results": res}

    # ---------- 2. renewal classification
    Xc, yc = df[RENEW_CAT + RENEW_NUM], df["renewed"]
    cands = {
        "LogisticRegression": Pipeline([("p", prep(True, RENEW_CAT, RENEW_NUM)),
                                        ("m", LogisticRegression(max_iter=1000))]),
        "RandomForest": Pipeline([("p", prep(False, RENEW_CAT, RENEW_NUM)),
                                  ("m", RandomForestClassifier(300, random_state=SEED, min_samples_leaf=3))]),
    }
    cvc = StratifiedKFold(5, shuffle=True, random_state=SEED)
    resc = {}
    for name, pipe in cands.items():
        s = cross_validate(pipe, Xc, yc, cv=cvc, scoring=("accuracy", "roc_auc"))
        resc[name] = {"cv_accuracy": round(float(s["test_accuracy"].mean()), 3),
                      "cv_auc": round(float(s["test_roc_auc"].mean()), 3)}
        print(f"[train] renew {name:<19} acc={resc[name]['cv_accuracy']:.3f}  AUC={resc[name]['cv_auc']:.3f}")
    bestc = max(resc, key=lambda k: resc[k]["cv_auc"])
    clf = cands[bestc].fit(Xc, yc)
    joblib.dump(clf, OUT_DIR / "renewal_model.joblib")
    metrics["renewal_classification"] = {"best_model": bestc, "cv_results": resc,
                                         "baseline_accuracy": round(float(max(yc.mean(), 1 - yc.mean())), 3)}

    metrics["note"] = ("Only 100 synthetic records: treat scores as a demonstration. "
                       "5-fold cross-validation is used because a single train/test split would be too noisy.")
    (OUT_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(f"[train] best rent model: {best} | best renewal model: {bestc} | saved in {OUT_DIR}")


if __name__ == "__main__":
    main()
