"""Exploratory data analysis: summary tables + charts saved to outputs/."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from config import DATA_FILE, OUT_DIR


def load() -> pd.DataFrame:
    df = pd.read_csv(DATA_FILE, parse_dates=["start_date"])
    df["rent_to_income"] = df["monthly_rent_zar"] / df["tenant_monthly_income_zar"]
    df["rent_per_sqm"] = df["monthly_rent_zar"] / df["size_sqm"]
    return df


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df = load()

    by_prov = (df.groupby("province")
                 .agg(properties=("record_id", "count"),
                      avg_rent=("monthly_rent_zar", "mean"),
                      median_rent=("monthly_rent_zar", "median"),
                      avg_rent_per_sqm=("rent_per_sqm", "mean"),
                      avg_rating=("tenant_rating", "mean"),
                      renewal_rate=("renewed", "mean"),
                      late_rate=("late_payment", "mean"))
                 .round(2).sort_values("avg_rent_per_sqm", ascending=False))
    by_type = (df.groupby("property_type")
                 .agg(properties=("record_id", "count"), avg_rent=("monthly_rent_zar", "mean"),
                      avg_size=("size_sqm", "mean"), renewal_rate=("renewed", "mean"))
                 .round(2).sort_values("avg_rent"))
    by_tenant = (df.groupby("tenant_type")
                   .agg(tenants=("record_id", "count"), avg_income=("tenant_monthly_income_zar", "mean"),
                        avg_rent=("monthly_rent_zar", "mean"), avg_rent_to_income=("rent_to_income", "mean"),
                        renewal_rate=("renewed", "mean"))
                   .round(2))
    by_prov.to_csv(OUT_DIR / "summary_by_province.csv")
    by_type.to_csv(OUT_DIR / "summary_by_property_type.csv")
    by_tenant.to_csv(OUT_DIR / "summary_by_tenant_type.csv")

    # ---- charts
    fig, ax = plt.subplots(figsize=(9, 5))
    by_prov["avg_rent_per_sqm"].sort_values().plot.barh(ax=ax, color="#c8642b")
    ax.set(title="Average rent per m² by province (fairer than total rent, which depends on property mix)",
           xlabel="ZAR per m²", ylabel="")
    ax.title.set_fontsize(9)
    fig.tight_layout(); fig.savefig(OUT_DIR / "rent_per_sqm_by_province.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    order = ["Room", "Flat", "Cottage", "House"]
    ax.boxplot([df.loc[df.property_type == t, "monthly_rent_zar"] for t in order], tick_labels=order)
    ax.set(title="Monthly rent by property type (ZAR)", ylabel="ZAR")
    fig.tight_layout(); fig.savefig(OUT_DIR / "rent_by_property_type.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    for t, g in df.groupby("property_type"):
        ax.scatter(g["size_sqm"], g["monthly_rent_zar"], label=t, alpha=0.8)
    ax.set(title="Rent vs size", xlabel="Size (m²)", ylabel="Monthly rent (ZAR)")
    ax.legend(); fig.tight_layout(); fig.savefig(OUT_DIR / "rent_vs_size.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    by_prov["renewal_rate"].sort_values().plot.barh(ax=ax, color="#2b7a78")
    ax.set(title="Lease renewal rate by province", xlabel="Share of tenants who renewed", ylabel="")
    fig.tight_layout(); fig.savefig(OUT_DIR / "renewal_by_province.png", dpi=130); plt.close(fig)

    num = df.select_dtypes("number").drop(columns=[])
    corr = num.corr()
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr))); ax.set_xticklabels(corr.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(len(corr))); ax.set_yticklabels(corr.columns, fontsize=7)
    fig.colorbar(im, ax=ax); ax.set_title("Correlation matrix")
    fig.tight_layout(); fig.savefig(OUT_DIR / "correlation_heatmap.png", dpi=130); plt.close(fig)

    print("[analysis] records:", len(df), "| missing values:", int(df.isna().sum().sum()))
    print(f"[analysis] average rent R{df.monthly_rent_zar.mean():,.0f} | renewal rate {df.renewed.mean():.0%}")
    print("[analysis] most expensive province per m²:", by_prov.index[0])
    print(f"[analysis] tables + 5 charts saved in {OUT_DIR}")


if __name__ == "__main__":
    main()
