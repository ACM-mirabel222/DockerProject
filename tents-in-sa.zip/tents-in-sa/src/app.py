"""Panel dashboard for Tents in SA: explore the data and use the ML models."""
import joblib
import pandas as pd
import panel as pn
import plotly.express as px

from config import LOCATIONS, OUT_DIR, PROPERTY_TYPES, TENANT_TYPES
from analysis import load

pn.extension("plotly", "tabulator", sizing_mode="stretch_width")

df = load()
rent_model = joblib.load(OUT_DIR / "rent_model.joblib")
renew_model = joblib.load(OUT_DIR / "renewal_model.joblib")
ACCENT = "#c8642b"

# ---------------------------------------------------------------- Explorer tab
provinces = sorted(df["province"].unique())
f_prov = pn.widgets.CheckBoxGroup(name="Province", options=provinces, value=provinces)
f_type = pn.widgets.CheckBoxGroup(name="Property type", options=PROPERTY_TYPES, value=PROPERTY_TYPES)


def filtered(prov, ptype):
    return df[df["province"].isin(prov) & df["property_type"].isin(ptype)]


def kpis(prov, ptype):
    d = filtered(prov, ptype)
    if d.empty:
        return pn.pane.Markdown("No properties match the filters.")
    return pn.Row(
        pn.indicators.Number(name="Properties", value=len(d), format="{value}"),
        pn.indicators.Number(name="Avg rent (R)", value=int(d.monthly_rent_zar.mean()), format="{value:,}"),
        pn.indicators.Number(name="Avg rating", value=round(d.tenant_rating.mean(), 2), format="{value}"),
        pn.indicators.Number(name="Renewal rate", value=round(d.renewed.mean() * 100), format="{value}%"),
    )


def rent_chart(prov, ptype):
    d = filtered(prov, ptype)
    if d.empty:
        return pn.pane.Markdown("")
    g = d.groupby("province", as_index=False)["monthly_rent_zar"].mean().sort_values("monthly_rent_zar")
    fig = px.bar(g, x="monthly_rent_zar", y="province", orientation="h",
                 title="Average monthly rent by province (ZAR)", color_discrete_sequence=[ACCENT])
    fig.update_layout(xaxis_title="ZAR", yaxis_title="", height=380)
    return pn.pane.Plotly(fig)


def scatter_chart(prov, ptype):
    d = filtered(prov, ptype)
    if d.empty:
        return pn.pane.Markdown("")
    fig = px.scatter(d, x="size_sqm", y="monthly_rent_zar", color="property_type", symbol="province",
                     hover_data=["record_id", "city", "tenant_rating"], title="Rent vs size")
    fig.update_layout(xaxis_title="Size (m²)", yaxis_title="Monthly rent (ZAR)", height=380)
    return pn.pane.Plotly(fig)


def table(prov, ptype):
    cols = ["record_id", "province", "city", "property_type", "bedrooms", "size_sqm",
            "monthly_rent_zar", "tenant_type", "tenant_rating", "renewed"]
    return pn.widgets.Tabulator(filtered(prov, ptype)[cols], show_index=False, page_size=10,
                                pagination="local", disabled=True)


explorer = pn.Row(
    pn.Column("### Filters", f_prov, f_type, width=230),
    pn.Column(
        pn.bind(kpis, f_prov, f_type),
        pn.Row(pn.bind(rent_chart, f_prov, f_type), pn.bind(scatter_chart, f_prov, f_type)),
        pn.bind(table, f_prov, f_type),
    ),
)

# ---------------------------------------------------------------- Rent predictor tab
p_prov = pn.widgets.Select(name="Province", options=list(LOCATIONS), value="Gauteng")
p_city = pn.widgets.Select(name="City", options=list(LOCATIONS["Gauteng"]))
p_type = pn.widgets.Select(name="Property type", options=PROPERTY_TYPES, value="Flat")
p_size = pn.widgets.IntSlider(name="Size (m²)", start=12, end=220, value=50)
p_bed = pn.widgets.IntSlider(name="Bedrooms", start=1, end=5, value=1)
p_bath = pn.widgets.IntSlider(name="Bathrooms", start=1, end=3, value=1)
p_dist = pn.widgets.FloatSlider(name="Distance to centre (km)", start=0, end=40, value=8, step=0.5)
p_furn = pn.widgets.Checkbox(name="Furnished")
p_wifi = pn.widgets.Checkbox(name="WiFi", value=True)
p_park = pn.widgets.Checkbox(name="Parking", value=True)
p_sec = pn.widgets.Checkbox(name="Security (fence / guard)")
p_pow = pn.widgets.Checkbox(name="Backup power (solar / inverter)")


def _sync_cities(event):
    p_city.options = list(LOCATIONS[event.new])
    p_city.value = p_city.options[0]


p_prov.param.watch(_sync_cities, "value")


def predict_rent(prov, city, ptype, size, bed, bath, dist, furn, wifi, park, sec, pw):
    row = pd.DataFrame([dict(province=prov, city=city, property_type=ptype, bedrooms=bed, bathrooms=bath,
                             size_sqm=size, furnished=int(furn), wifi=int(wifi), parking=int(park),
                             security=int(sec), backup_power=int(pw), distance_to_centre_km=dist)])
    price = float(rent_model.predict(row)[0])
    return pn.indicators.Number(name="Suggested monthly rent", value=int(round(price / 50) * 50),
                                format="R {value:,}", font_size="36pt", default_color=ACCENT)


rent_tab = pn.Row(
    pn.Column("### Describe the property", p_prov, p_city, p_type, p_size, p_bed, p_bath, p_dist,
              p_furn, p_wifi, p_park, p_sec, p_pow, width=300),
    pn.Column("### Rent estimate",
              pn.bind(predict_rent, p_prov, p_city, p_type, p_size, p_bed, p_bath, p_dist,
                      p_furn, p_wifi, p_park, p_sec, p_pow),
              pn.pane.Markdown("_Model trained on 100 synthetic records - for demonstration only._")),
)

# ---------------------------------------------------------------- Renewal predictor tab
r_prov = pn.widgets.Select(name="Province", options=list(LOCATIONS), value="Gauteng")
r_type = pn.widgets.Select(name="Property type", options=PROPERTY_TYPES, value="Flat")
r_ten = pn.widgets.Select(name="Tenant type", options=TENANT_TYPES, value="Young Professional")
r_rent = pn.widgets.IntInput(name="Monthly rent (R)", value=7000, step=250)
r_inc = pn.widgets.IntInput(name="Tenant monthly income (R)", value=25000, step=500)
r_rate = pn.widgets.FloatSlider(name="Tenant rating (1-5)", start=1, end=5, value=4.0, step=0.1)
r_lease = pn.widgets.Select(name="Lease length (months)", options=[6, 12, 24], value=12)
r_age = pn.widgets.IntSlider(name="Tenant age", start=18, end=65, value=30)
r_late = pn.widgets.Checkbox(name="Has paid late")
r_furn = pn.widgets.Checkbox(name="Furnished")
r_sec = pn.widgets.Checkbox(name="Security")


def predict_renewal(prov, ptype, ten, rent, inc, rate, lease, age, late, furn, sec):
    row = pd.DataFrame([dict(province=prov, property_type=ptype, tenant_type=ten, monthly_rent_zar=rent,
                             tenant_monthly_income_zar=max(inc, 1), rent_to_income=rent / max(inc, 1),
                             tenant_rating=rate, late_payment=int(late), lease_months=lease,
                             tenant_age=age, furnished=int(furn), security=int(sec))])
    prob = float(renew_model.predict_proba(row)[0, 1])
    msg = ("Likely to renew" if prob >= 0.6 else "Uncertain - worth a check-in" if prob >= 0.4
           else "At risk of leaving - consider a retention offer")
    return pn.Column(
        pn.indicators.Number(name="Renewal probability", value=round(prob * 100), format="{value}%",
                             font_size="36pt", default_color=ACCENT),
        pn.pane.Markdown(f"**{msg}**  \nRent-to-income ratio: {rent / max(inc, 1):.0%}"),
    )


renew_tab = pn.Row(
    pn.Column("### Describe the tenancy", r_prov, r_type, r_ten, r_rent, r_inc, r_rate, r_lease, r_age,
              r_late, r_furn, r_sec, width=300),
    pn.Column("### Retention outlook",
              pn.bind(predict_renewal, r_prov, r_type, r_ten, r_rent, r_inc, r_rate, r_lease, r_age,
                      r_late, r_furn, r_sec)),
)

# ---------------------------------------------------------------- Model report tab
metrics_md = (OUT_DIR / "metrics.json").read_text()
report_tab = pn.Column(
    "### Model performance (5-fold cross-validation)",
    pn.pane.Markdown(f"```json\n{metrics_md}\n```"),
    "### Charts from the analysis step",
    pn.Row(pn.pane.PNG(str(OUT_DIR / "rent_by_property_type.png"), width=420),
           pn.pane.PNG(str(OUT_DIR / "renewal_by_province.png"), width=420)),
    pn.pane.PNG(str(OUT_DIR / "correlation_heatmap.png"), width=560),
)

app = pn.template.FastListTemplate(
    title="Tents in SA - Rental Analytics",
    accent=ACCENT, header_background=ACCENT,
    main=[pn.Tabs(("Explore data", explorer), ("Rent predictor", rent_tab),
                  ("Renewal predictor", renew_tab), ("Model report", report_tab))],
)
app.servable()
