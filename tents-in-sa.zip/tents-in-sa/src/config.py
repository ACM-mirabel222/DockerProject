"""Shared paths and constants for the Tents in SA project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "outputs"
DATA_FILE = DATA_DIR / "tents_in_sa_rentals.csv"

SEED = 42
N_RECORDS = 100

# province -> {city: rent price index (1.0 = national baseline)}
LOCATIONS = {
    "Gauteng": {"Sandton": 1.35, "Johannesburg": 1.05, "Pretoria": 1.00},
    "Western Cape": {"Cape Town": 1.30, "Stellenbosch": 1.15},
    "KwaZulu-Natal": {"Durban": 1.00, "Pietermaritzburg": 0.80},
    "Eastern Cape": {"Gqeberha": 0.85, "East London": 0.80},
    "Free State": {"Bloemfontein": 0.80},
    "Limpopo": {"Polokwane": 0.75},
    "Mpumalanga": {"Mbombela": 0.85},
    "North West": {"Rustenburg": 0.75},
    "Northern Cape": {"Kimberley": 0.70},
}

PROPERTY_TYPES = ["Room", "Flat", "Cottage", "House"]
TENANT_TYPES = ["Student", "Young Professional", "Family", "Contract Worker"]

CITY_TO_PROVINCE = {c: p for p, cs in LOCATIONS.items() for c in cs}
