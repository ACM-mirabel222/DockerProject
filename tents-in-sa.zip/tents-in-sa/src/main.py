"""Docker entrypoint: (generate data) -> analysis -> train models -> start dashboard."""
import os
import sys

import analysis
import generate_data
import train_model
from config import DATA_FILE

if __name__ == "__main__":
    if not DATA_FILE.exists():
        generate_data.main()
    analysis.main()
    train_model.main()
    print("\n>>> Dashboard starting: open http://localhost:5006/app in your browser\n", flush=True)
    here = os.path.dirname(os.path.abspath(__file__))
    os.execvp(sys.executable, [
        sys.executable, "-m", "panel", "serve", os.path.join(here, "app.py"),
        "--address", "0.0.0.0", "--port", "5006",
        "--allow-websocket-origin", "localhost:5006",
        "--allow-websocket-origin", "127.0.0.1:5006",
    ])
